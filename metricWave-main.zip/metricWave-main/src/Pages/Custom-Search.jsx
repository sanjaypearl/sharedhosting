import React from 'react'

const CustomSearch = () => {
  return (
    <div>Custom-Search</div>
  )
}

export default CustomSearch