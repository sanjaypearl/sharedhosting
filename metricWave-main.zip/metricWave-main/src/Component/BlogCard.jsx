import React from 'react'

const BlogCard = () => {
  return (
    <div>BlogCard</div>
  )
}

export default BlogCard